package dtos

type NewApiKeyResult struct {
	Name string `json:"name"`
	Key  string `json:"key"`
}
