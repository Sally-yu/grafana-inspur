package extensions

import (
	_ "gopkg.in/square/go-jose.v2"
)

var IsEnterprise bool = false
