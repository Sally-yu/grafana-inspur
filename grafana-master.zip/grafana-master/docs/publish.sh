#!/bin/bash

make publish ENV=prod VERSION=root
