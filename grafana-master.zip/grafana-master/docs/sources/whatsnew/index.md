+++
title = "What's New in Grafana"
[menu.docs]
name = "What's New In Grafana"
identifier = "whatsnew"
weight = 5
+++


