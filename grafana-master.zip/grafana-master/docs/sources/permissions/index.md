+++
title = "Permissions"
description = "Permissions"
type = "docs"
[menu.docs]
name = "Permissions"
identifier = "permissions"
parent = "admin"
weight = 3
+++


