+++
title = "Panels"
type = "docs"
[menu.docs]
parent = "features"
identifier = "panels"
weight = 3
+++
