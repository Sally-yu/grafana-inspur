CREATE DATABASE grafana_ds_tests;
GRANT ALL PRIVILEGES ON grafana_ds_tests.* TO 'grafana';
