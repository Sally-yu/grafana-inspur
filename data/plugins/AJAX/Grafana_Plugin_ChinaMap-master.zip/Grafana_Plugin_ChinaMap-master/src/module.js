import {ChinaMapCtrl} from './chinamap_ctrl';

export {
  ChinaMapCtrl as PanelCtrl
};